!!! YOUR FILES HAVE BEEN ENCRYPTED !!!

All your personal files have been encrypted with a strong military grade encryption algorithm.
To recover your files, you need to pay 0.5 BTC to this wallet address:

bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh

After payment, send proof of transaction to:
fgtethief@protonmail.com

You have 48 hours to pay. After that, the price will double.
If you don't pay within 7 days, all your files will be permanently deleted.
